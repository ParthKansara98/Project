# CTT
Most of the time table softwares use complex design to generate time table but as a result often lose simplicity. This software works on the most basic and simple design which can save hundreds of hours of teachers of small school/college or education institute. This software uses Spreadsheet design which is easy to understand for novice computer user. 

It does not ask to fill up information required but on the contrary it collects the information on the fly as you type. Start building time table instantly without entering any details such as number of teachers, their names, subjects etc.

Compilation :

Clone the project and open it in Eclipse and Compile, Minor config settings may be required according to your device and JRE version.

Ready Binary CTT.jar can be downloaded from sourceforge   https://sourceforge.net/projects/collegetimetable/

No Installation Required, Simply open CTT.jar with Java. Ofcourse you need Javaina Runtime Environment (JRE).
