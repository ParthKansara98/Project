package ctt;

public class Demo 
{
	static String demoarr[][]={

			{"12:30-01:10"},
			{"FY-A","ENG(MN)","ECO(CD)","SEP(AB)","SEP(AB)","ECO(CD)","SEP(AB)"},
			{"FY-B","ACS(EF)","MAR(IJ),HIN(KL)","MAR(IJ),HIN(KL)","ORC(GH)","SEP(AB)","MAR(IJ),HIN(KL)"},
			{"SY-A","ORC(GH)","ACS(EF)","ACS(EF)","ECO(CD)","ACS(EF)","ACS(EF)"},
			{"SY-B","SEP(AB)","ENG(MN)","ORC(GH)","ENG(MN)","ORC(GH)","ORC(GH)"},
			{""},
			{"01:10-01:50"},
			{"FY-A","MAR(IJ),HIN(KL)","ECO(CD)","MAR(IJ),HIN(KL)","ENG(MN)","ENG(MN)","MAR(IJ),HIN(KL)"},
			{"FY-B","SEP(AB)","ACS(EF)","SEP(AB)","SEP(AB)","ACS(EF)","ACS(EF)"},
			{"SY-A","ACS(EF)","ENG(MN)","ORC(GH)","ORC(GH)","ORC(GH)","ORC(GH)"},
			{"SY-B","ORC(GH)","MAR(IJ),HIN(KL)","ECO(CD)","ECO(CD)","SEP(AB)","SEP(AB)"},
			{""},
			{"01:50-02:30"},
			{"FY-A","ECO(CD)","ACS(EF)","ORC(GH)","ORC(GH)","MAR(IJ),HIN(KL)","ORC(GH)"},
			{"FY-B","ENG(MN)","ECO(CD)","ECO(CD)","MAR(IJ),HIN(KL)","ORC(GH)","ENG(MN)"},
			{"SY-A","SEP(AB)","ORC(GH)","ENG(MN)","ENG(MN)","SEP(AB)","MAR(IJ),HIN(KL)"},
			{"SY-B","MAR(IJ),HIN(KL)","SEP(AB)","SEP(AB)","SEP(AB)","ACS(EF)","ACS(EF)"},
			{""},
			{"03:00-03:40"},
			{"FY-A","ORC(GH)","MAR(IJ),HIN(KL)","MAR(IJ),HIN(KL)","ACS(EF)","ORC(GH)","ACS(EF)"},
			{"FY-B","MAR(IJ),HIN(KL)","ACS(EF)","ACS(EF)","ENG(MN)","MAR(IJ),HIN(KL)","ECO(CD)"},
			{"SY-A","ENG(MN)","SEP(AB)","SEP(AB)","ECO(CD)","ECO(CD)","SEP(AB)"},
			{"SY-B","ECO(CD)","ORC(GH)","ENG(MN)","ORC(GH)","ENG(MN)","ENG(MN)"},
			{""},
		    {"03:40-04:20"}, 
			{"FY-A","SEP(AB)","ORC(GH)","ACS(EF)","ENG(MN)","SEP(AB)","ENG(MN)"},
			{"FY-B","ECO(CD)","SEP(AB)","ORC(GH)","ECO(CD)","ECO(CD)","SEP(AB)"},
			{"SY-A","MAR(IJ),HIN(KL)","ECO(CD)","ECO(CD)","ACS(EF)","ENG(MN)","ECO(CD)"},
			{"SY-B","ACS(EF)","ACS(EF)","MAR(IJ),HIN(KL)","MAR(IJ),HIN(KL)","MAR(IJ),HIN(KL)","MAR(IJ),HIN(KL)"},
			{""},
			{"04:20-05:00"} ,
			{"FY-A","ACS(EF)","ENG(MN)","ECO(CD)","ECO(CD)","ACS(EF)","SEP(AB)"},
			{"FY-B","ORC(GH)","ORC(GH)","ENG(MN)","ENG(MN)","ENG(MN)","ORC(GH)"},
			{"SY-A","SEP(AB)","MAR(IJ),HIN(KL)","MAR(IJ),HIN(KL)","MAR(IJ),HIN(KL)","MAR(IJ),HIN(KL)","ENG(MN)"},
			{"SY-B","ENG(MN)","ECO(CD)","ACS(EF)","ACS(EF)","ECO(CD)","ECO(CD)"},
			{""}
			};


	
	
	
//		RefreshFormat();
			
		}


