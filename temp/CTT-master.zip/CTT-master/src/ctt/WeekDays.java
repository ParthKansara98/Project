package ctt;



/// To Set your own Order of WeekDays, replace appropriate string
/// comment other week days strings
/// This order will be used in all the displays and printouts
/// Always use First array element as TIME
/// Do not use Fewer days. For 5 days or less days per week, just do not enter
/// data on off days


public class WeekDays 
{
   String weekdays[] = { "TIME", "MON", "TUE" ,"WED","THU","FRI","SAT"};
   //String weekdays[] = { "TIME", "SAT", "SUN" ,"MON","TUE","WED","THU"};
}
